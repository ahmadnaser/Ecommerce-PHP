-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 28, 2012 at 05:04 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dc_force1`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `type` int(2) NOT NULL,
  `post` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `userid`, `title`, `text`, `type`, `post`, `email`, `date`, `name`) VALUES
(1, 0, 'hi', 'keefo', 1, 0, 'mo7@hi.com', '2012-08-13 07:49:38', 'moha'),
(2, 0, 'hi', 'sfsdfsdfsdf', 1, 0, 'm@d.d', '2012-08-13 07:53:09', 'ggg'),
(3, 0, 'hi', 'kdfkkdfkdf', 1, 0, 'sdsd@sdsd.d', '2012-08-13 11:21:49', 'hjkl'),
(4, 0, 'hi', 'Aaaad', 1, 0, 'ahmadnassr@gmail.com', '2012-08-13 12:53:48', 'Silwadapp'),
(5, 0, 'hi', 'Aaaad', 1, 0, 'ahmadnassr@gmail.com', '2012-08-13 12:55:32', 'Silwadapp'),
(6, 0, 'hi', 'Aaaad', 1, 0, 'ahmadnassr@gmail.com', '2012-08-13 12:57:38', 'Silwadapp'),
(7, 0, 'hi', 'Aaaad', 1, 0, 'ahmadnassr@gmail.com', '2012-08-13 12:58:27', 'Silwadapp'),
(8, 0, 'hi', 'Aaaad', 1, 0, 'ahmadnassr@gmail.com', '2012-08-13 12:58:33', 'Silwadapp'),
(9, 0, 'hi', 'FSaf', 1, 0, 'Naser', '2012-08-13 13:01:14', 'Ahmad'),
(10, 0, 'hi', 'ouuot', 1, 0, 'sterio_king@hotmail.com', '2012-08-13 13:01:39', 'Silwadapp'),
(11, 0, 'hi', 'asfsafd', 1, 0, 'dimensions.mailer@gmail.com', '2012-08-13 13:02:09', 'qrt4w'),
(12, 0, 'hi', 'afsdsfdafs', 1, 0, 'afsadsfa', '2012-08-13 13:07:05', 'dssfd'),
(13, 0, 'hi', 'asdds', 1, 0, 'adsasd', '2012-08-13 13:07:13', 'asdads'),
(14, 0, 'hi', 'Tttttttt', 1, 0, 'Ttttttt', '2012-08-13 23:37:58', 'Tttttt');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(45) NOT NULL,
  `lastName` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `birth` date NOT NULL,
  `telephone` varchar(45) NOT NULL,
  `status` int(1) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `hash` varchar(255) NOT NULL,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`userid`, `firstName`, `lastName`, `password`, `address`, `email`, `birth`, `telephone`, `status`, `type`, `hash`) VALUES
(54, 'Your', 'Secret', '68aa098cbefcd1842d4377c430141d25', 'Ramallah', 'yoursecretsonline@gmail.com', '0000-00-00', '3757834', 1, 1, '68aa098cbefcd1842d4377c430141d257f9cce670dc8953621cc6c86f6f5900d');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE IF NOT EXISTS `post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `shortdescription` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `title`, `description`, `image`, `shortdescription`, `type`, `status`) VALUES
(44, 'ygfrgyrgygygy gy r', 'ygwegysgdygyudsg yuguy dsg dg guydsgyu dsfgygdgy sdygu dfyg gyfdguyf du sfdsguf dgu dsgyu fygsfdgyuf dguf dugf yugf ugufsugfd gfdugf dgusfd ufs gsuf dugfd ggsf guysf dgyusfd uygwegysgdygyudsg yuguy dsg dg guydsgyu dsfgygdgy sdygu dfyg gyfdguyf du sfdsguf dgu dsgyu fygsfdgyuf dguf dugf yugf ugufsugfd gfdugf dgusfd ufs gsuf dugfd ggsf guysf dgyusfd uygwegysgdygyudsg yuguy dsg dg guydsgyu dsfgygdgy sdygu dfyg gyfdguyf du sfdsguf dgu dsgyu fygsfdgyuf dguf dugf yugf ugufsugfd gfdugf dgusfd ufs gsuf dugfd ggsf guysf dgyusfd uygwegysgdygyudsg yuguy dsg dg guydsgyu dsfgygdgy sdygu dfyg gyfdguyf du sfdsguf dgu dsgyu fygsfdgyuf dguf dugf yugf ugufsugfd gfdugf dgusfd ufs gsuf dugfd ggsf guysf dgyusfd u<br><div>ygwegysgdygyudsg yuguy dsg dg guydsgyu dsfgygdgy sdygu dfyg gyfdguyf du sfdsguf dgu dsgyu fygsfdgyuf dguf dugf yugf ugufsugfd gfdugf dgusfd ufs gsuf dugfd ggsf guysf dgyusfd uygwegysgdygyudsg yuguy dsg dg guydsgyu dsfgygdgy sdygu dfyg gyfdguyf du sfdsguf dgu dsgyu fygsfdgyuf dguf dugf yugf ugufsugfd gfdugf dgusfd ufs gsuf dugfd ggsf guysf dgyusfd u<br></div><div><br></div><div><br></div><div>ygwegysgdygyudsg yuguy dsg dg guydsgyu dsfgygdgy sdygu dfyg gyfdguyf du sfdsguf dgu dsgyu fygsfdgyuf dguf dugf yugf ugufsugfd gfdugf dgusfd ufs gsuf dugfd ggsf guysf dgyusfd uygwegysgdygyudsg yuguy dsg dg guydsgyu dsfgygdgy sdygu dfyg gyfdguyf du sfdsguf dgu dsgyu fygsfdgyuf dguf dugf yugf ugufsugfd gfdugf dgusfd ufs gsuf dugfd ggsf guysf dgyusfd uygwegysgdygyudsg yuguy dsg dg guydsgyu dsfgygdgy sdygu dfyg gyfdguyf du sfdsguf dgu dsgyu fygsfdgyuf dguf dugf yugf ugufsugfd gfdugf dgusfd ufs gsuf dugfd ggsf guysf dgyusfd uygwegysgdygyudsg yuguy dsg dg guydsgyu dsfgygdgy sdygu dfyg gyfdguyf du sfdsguf dgu dsgyu fygsfdgyuf dguf dugf yugf ugufsugfd gfdugf dgusfd ufs gsuf dugfd ggsf guysf dgyusfd uygwegysgdygyudsg yuguy dsg dg guydsgyu dsfgygdgy sdygu dfyg gyfdguyf du sfdsguf dgu dsgyu fygsfdgyuf dguf dugf yugf ugufsugfd gfdugf dgusfd ufs gsuf dugfd ggsf guysf dgyusfd u<br></div>', 'Chrysanthemum.jpg', 'ygwegysgdygyudsg yuguy dsg dg guydsgyu dsfgygdgy sdygu dfyg gyfdguyf du sfdsguf dgu dsgyu fygsfdgyuf dguf dugf yugf ugufsugfd gfdugf dgusfd ufs gsuf dugfd ggsf guysf dgyusfd u', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `searchcontent`
--

CREATE TABLE IF NOT EXISTS `searchcontent` (
  `id` int(10) unsigned NOT NULL,
  `title` varchar(45) NOT NULL,
  `href` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `searchcontent`
--

INSERT INTO `searchcontent` (`id`, `title`, `href`) VALUES
(1, 'overview', 'Overview.php'),
(2, 'management', 'Management.php'),
(3, 'Firas Zaghal, CEO', 'Management.php'),
(4, 'testimonials', 'Testimonials.php'),
(5, 'media room', 'Media.php'),
(6, 'what we do', 'WhatWeDo.php'),
(7, 'organizational planning', 'WhatWeDo.php'),
(8, 'research', 'WhatWeDo.php'),
(9, 'financial advisory', 'WhatWeDo.php'),
(10, 'organization development', 'WhatWeDo.php'),
(11, 'marketing managment', 'WhatWeDo.php'),
(12, 'training', 'WhatWeDo.php'),
(13, 'who we serve', 'WhoWeServe.php'),
(14, 'latest thinking', 'LatestThinking.php'),
(15, 'contant us', 'ContactUs.php'),
(16, 'site map', 'Sitemap.php'),
(17, 'privacy policy', 'Privacypolicy.php'),
(18, 'term of use', 'Termsofuse.php'),
(19, 'home', 'index.php'),
(20, 'services', 'index.php'),
(21, 'management team', 'index.php'),
(22, 'selected client', 'index.php'),
(23, 'content', 'index.php'),
(24, 'company', 'index.php');

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE IF NOT EXISTS `subscribers` (
  `email` varchar(45) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`email`) VALUES
('GO');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
