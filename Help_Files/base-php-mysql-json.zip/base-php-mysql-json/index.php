<?php require_once './includes/dbcon.php'; 


echo  BASEURL;

echo CONDIR;

echo ROOTDIR;

$link=open_database_connection();
//print_r(get_all_posts());
//web_service_call();
all_posts();


close_database_connection($link);


?>

<?php
 function all_posts()
{
    global $link; 

$sql="SELECT `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count` FROM `wp_posts` ";

$result = mysql_query($sql, $link);

    $posts = array();
    while ($row = mysql_fetch_assoc($result)) {
        $posts[] = $row;
    }
    

    print_r( $posts );
}
?>